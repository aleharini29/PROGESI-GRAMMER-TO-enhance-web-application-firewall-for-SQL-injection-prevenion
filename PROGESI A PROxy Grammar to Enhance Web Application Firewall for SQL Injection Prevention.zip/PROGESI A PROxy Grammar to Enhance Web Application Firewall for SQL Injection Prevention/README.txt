README - PROGESI: A Proxy Grammar to Enhance Web Application Firewall for SQL Injection Prevention
==================================================================================================

## Overview
-----------
PROGESI is a machine learning-powered enhancement for Web Application Firewalls (WAFs) that protects against SQL Injection (SQLi) attacks. It uses a Proxy Grammar approach to analyze the structure of SQL queries and apply various ML/DL models (BiLSTM, SVM, Random Forest, Logistic Regression) to classify them as benign or malicious. The system is designed to detect complex, obfuscated, and evolving SQLi attacks with high accuracy and minimal false positives.

## Features
-----------
- Real-time SQLi detection using trained ML/DL models
- Proxy Grammar-based structural analysis of queries
- Model training on custom datasets
- Query classification as "Safe" or "SQL Injection Detected"
- Graphical comparison of model performance (accuracy, precision, recall, F1 score)
- Security recommendations on detection

## Additional Features
----------------------
- Support for multiple models: BiLSTM, SVM, Random Forest, Logistic Regression
- Model evaluation and visualization
- Lightweight and modular codebase
- Easy integration into existing WAF systems
- Tkinter-based user-friendly interface for non-technical users

## Technology Stack
-------------------

Frontend:
- Python Tkinter (for GUI)
- Matplotlib, Seaborn (for graphs and charts)

Backend:
- Python 3.7
- Libraries: NumPy, Pandas, Scikit-learn, TensorFlow, Keras, Pickle/Joblib

## Database
-----------
- Dataset-based: The system uses a labeled CSV dataset of SQL queries (benign/malicious) instead of a traditional database.
- No external database integration required.

## Installation & Setup
------------------------

1. **Install Python 3.7** if not already installed.
2. **Install the required libraries:**
3. **Clone or download the project files.**
4. **Place your labeled dataset CSV file in the root directory.**

## Backend Setup
------------------
- Backend code is written in Python.
- Models are trained using TensorFlow/Keras or Scikit-learn.
- Model files can be saved and loaded using `joblib` or `pickle`.

## Frontend Setup
-------------------
- Uses `tkinter` for the desktop GUI.
- Run `main.py` to launch the interface.

## Usage Guide
--------------
1. Launch the app using:
2. Upload your labeled dataset (CSV file with SQL queries and labels).
3. Preprocess the dataset.
4. Train any or all ML/DL models (BiLSTM, SVM, RF, LR).
5. View model comparison graph for accuracy.
6. Enter custom SQL queries in the prediction window.
7. View results and recommended actions.

## Future Enhancements
-----------------------
- Integration with cloud-based WAFs and APIs
- Federated learning for decentralized training
- Deep reinforcement learning for adaptive protection
- Detection of hybrid attacks (XSS, SSRF)
- Web-based GUI for better portability
- Multi-language SQLi detection support

## Contributors
---------------
- Ale Harini (21B81A3317) – Feature extraction, SVM implementation, WAF integration
- Sirasawada Pravalika (21B81A3332) – Data collection, preprocessing, BiLSTM training
- Meela Sreeja (21B81A3349) – UI design, Random Forest & Logistic Regression, visualizations

## Guide
----------
- Dr. Afreen Fatima Mohammed – Assistant Professor, CSE(DS), CVR College of Engineering

## License
----------
This project is part of an academic submission. Free to use for research and educational purposes.


